var pi = 3.141592;
console.log(pi);
