console.log(pi);
let pi = 3.141592;
