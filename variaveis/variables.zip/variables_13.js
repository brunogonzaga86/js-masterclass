const pi = 3.141592;
console.log(pi);
pi = 3;
console.log(pi);
