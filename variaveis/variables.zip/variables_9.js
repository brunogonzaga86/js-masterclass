let pi = 3.141592;
console.log(pi);
let pi = 3;
console.log(pi);
