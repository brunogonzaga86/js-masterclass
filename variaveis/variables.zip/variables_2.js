console.log(pi);
var pi = 3.141592;
