const pi = 3.141592;
console.log(pi);
const pi = 3;
console.log(pi);
